package com.example.hello;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import static android.content.ContentValues.TAG;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    public int[] parking_lot_id = {R.id.A_1, R.id.A_2, R.id.A_3, R.id.A_4, R.id.A_5, R.id.A_6, R.id.A_7, R.id.A_8};
    public  View[] A = new View[parking_lot_id.length];
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    String[] paths = {"A/1", "A/2", "A/3", "A/4", "A/5", "A/6", "A/7", "A/8"};
    String[] parking_date_array;
    DatabaseReference[] myRef = new DatabaseReference[paths.length];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        for (int i = 0; i < parking_lot_id.length; i++) A[i] = findViewById(parking_lot_id[i]);
        for (int i = 0; i < parking_lot_id.length; i++) myRef[i] = database.getReference(paths[i]);

        updateStatus();
        setupImageViews();
    }

    public void setupImageViews() {
        Class[] activities = {ChildActivity_A1.class, activity_child_A2.class};
        for (int i = 0; i < parking_lot_id.length; i++) {
            final int index = i;
            A[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainActivity.this, activities[index]);
                    startActivity(intent);
                }
            });
            }
        }

        private void updateStatus(){
            for (int i = 0; i < parking_lot_id.length; i++) {
                int finalI = i;
                myRef[i].child("status").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String value = dataSnapshot.getValue(String.class);
                        A[finalI].setAlpha(Float.parseFloat(value));
                    }
                    @Override
                    public void onCancelled(DatabaseError error) {
                        // Failed to read value
                        Log.w(TAG, "Failed to read value.", error.toException());
                    }
                });
            }
        }
}


